package assignment.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigSettings {
    private static final String PROPERTIES_FILE = "config.properties";
    private static Properties properties;

    static {
        properties = new Properties();
        try (InputStream inputStream = ConfigSettings.class.getClassLoader().getResourceAsStream(PROPERTIES_FILE)) {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getApiUrl() {
        return properties.getProperty("API_URL");
    }

    public static String getRestApiKey() {
        return properties.getProperty("REST_API_KEY");
    }

    public static String getRegionInfoExcelSrc() {
        return properties.getProperty("REGION_INFO_EXCEL_SRC");
    }
}