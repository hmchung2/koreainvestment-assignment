package assignment.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import assignment.model.KakaoApi.RoadAddress;

public class ServiceOutput {
    @JsonProperty("address_name")
    private String addressName;

    @JsonProperty("region_1depth_name")
    private String region1DepthName;

    @JsonProperty("region_2depth_name")
    private String region2DepthName;

    @JsonProperty("region_3depth_name")
    private String region3DepthName;

    @JsonProperty("road_name")
    private String roadName;

    @JsonProperty("underground_yn")
    private String undergroundYn;

    @JsonProperty("main_building_no")
    private String mainBuildingNo;

    @JsonProperty("sub_building_no")
    private String subBuildingNo;

    @JsonProperty("building_name")
    private String buildingName;

    @JsonProperty("zone_no")
    private String zoneNo;

    @JsonProperty("x")
    private String x;

    @JsonProperty("y")
    private String y;

    private boolean apiSuccess;
    private String errMsg;
    private String validLevel;

    // default constructor
    public ServiceOutput() {
        this.apiSuccess = false;
        this.errMsg = "Transaction not completed";
        this.validLevel = "1";
    }

    // add getters and setters here for the new fields

    public boolean getApiSuccess() {
        return apiSuccess;
    }

    public void setApiSuccess(boolean success) {
        this.apiSuccess = success;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public String getValidLevel() {
        return validLevel;
    }

    public void setValidLevel(String validLevel) {
        this.validLevel = validLevel;
    }
    
    public void setAddressName(String addressName) {
        this.addressName = addressName;
    }

    public void setRegion1DepthName(String region1DepthName) {
        this.region1DepthName = region1DepthName;
    }

    public void setRegion2DepthName(String region2DepthName) {
        this.region2DepthName = region2DepthName;
    }

    public void setRegion3DepthName(String region3DepthName) {
        this.region3DepthName = region3DepthName;
    }

    public void setRoadName(String roadName) {
        this.roadName = roadName;
    }

    public void setUndergroundYn(String undergroundYn) {
        this.undergroundYn = undergroundYn;
    }

    public void setMainBuildingNo(String mainBuildingNo) {
        this.mainBuildingNo = mainBuildingNo;
    }

    public void setSubBuildingNo(String subBuildingNo) {
        this.subBuildingNo = subBuildingNo;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public void setZoneNo(String zoneNo) {
        this.zoneNo = zoneNo;
    }

    public void setX(String x) {
        this.x = x;
    }

    public void setY(String y) {
        this.y = y;
    }

    public void copyFromRoadAddress(RoadAddress roadAddress) {
        this.addressName = roadAddress.getAddressName();
        this.region1DepthName = roadAddress.getRegion1DepthName();
        this.region2DepthName = roadAddress.getRegion2DepthName();
        this.region3DepthName = roadAddress.getRegion3DepthName();
        this.roadName = roadAddress.getRoadName();
        this.undergroundYn = roadAddress.getUndergroundYn();
        this.mainBuildingNo = roadAddress.getMainBuildingNo();
        this.subBuildingNo = roadAddress.getSubBuildingNo();
        this.buildingName = roadAddress.getBuildingName();
        this.zoneNo = roadAddress.getZoneNo();
        this.x = roadAddress.getX();
        this.y = roadAddress.getY();
    }

    @Override
    public String toString() {
        return "ServiceOutput{" +
                "addressName='" + addressName + '\'' +
                ", region1DepthName='" + region1DepthName + '\'' +
                ", region2DepthName='" + region2DepthName + '\'' +
                ", region3DepthName='" + region3DepthName + '\'' +
                ", roadName='" + roadName + '\'' +
                ", undergroundYn='" + undergroundYn + '\'' +
                ", mainBuildingNo='" + mainBuildingNo + '\'' +
                ", subBuildingNo='" + subBuildingNo + '\'' +
                ", buildingName='" + buildingName + '\'' +
                ", zoneNo='" + zoneNo + '\'' +
                ", x='" + x + '\'' +
                ", y='" + y + '\'' +
                ", success=" + apiSuccess +
                ", errMsg='" + errMsg + '\'' +
                ", validLevel='" + validLevel + '\'' +
                '}';
    }
}
