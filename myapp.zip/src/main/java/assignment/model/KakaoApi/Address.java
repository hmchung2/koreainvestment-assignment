package assignment.model.KakaoApi;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
    @JsonProperty("address_name")
    private String addressName;

    @JsonProperty("region_1depth_name")
    private String region1DepthName;

    @JsonProperty("region_2depth_name")
    private String region2DepthName;

    @JsonProperty("region_3depth_name")
    private String region3DepthName;

    @JsonProperty("region_3depth_h_name")
    private String region3DepthHName;

    @JsonProperty("h_code")
    private String hCode;

    @JsonProperty("b_code")
    private String bCode;

    @JsonProperty("mountain_yn")
    private String mountainYn;

    @JsonProperty("main_address_no")
    private String mainAddressNo;

    @JsonProperty("sub_address_no")
    private String subAddressNo;

    @JsonProperty("x")
    private String x;

    @JsonProperty("y")
    private String y;

    // Add getters and setters for the fields

    public String getAddressName() {
        return addressName;
    }

    public void setAddressName(String addressName) {
        this.addressName = addressName;
    }

    public String getRegion1DepthName() {
        return region1DepthName;
    }

    public void setRegion1DepthName(String region1DepthName) {
        this.region1DepthName = region1DepthName;
    }

    public String getRegion2DepthName() {
        return region2DepthName;
    }

    public void setRegion2DepthName(String region2DepthName) {
        this.region2DepthName = region2DepthName;
    }

    public String getRegion3DepthName() {
        return region3DepthName;
    }

    public void setRegion3DepthName(String region3DepthName) {
        this.region3DepthName = region3DepthName;
    }

    public String getRegion3DepthHName() {
        return region3DepthHName;
    }

    public void setRegion3DepthHName(String region3DepthHName) {
        this.region3DepthHName = region3DepthHName;
    }

    public String gethCode() {
        return hCode;
    }

    public void sethCode(String hCode) {
        this.hCode = hCode;
    }

    public String getbCode() {
        return bCode;
    }

    public void setbCode(String bCode) {
        this.bCode = bCode;
    }

    public String getMountainYn() {
        return mountainYn;
    }

    public void setMountainYn(String mountainYn) {
        this.mountainYn = mountainYn;
    }

    public String getMainAddressNo() {
        return mainAddressNo;
    }

    public void setMainAddressNo(String mainAddressNo) {
        this.mainAddressNo = mainAddressNo;
    }

    public String getSubAddressNo() {
        return subAddressNo;
    }

    public void setSubAddressNo(String subAddressNo) {
        this.subAddressNo = subAddressNo;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }
    
    public RoadAddress toRoadAddress() {
        RoadAddress roadAddress = new RoadAddress();
        roadAddress.setAddressName(this.getAddressName());
        roadAddress.setRegion1DepthName(this.getRegion1DepthName());
        roadAddress.setRegion2DepthName(this.getRegion2DepthName());
        roadAddress.setRegion3DepthName(this.getRegion3DepthName());
        roadAddress.setX(this.getX());
        roadAddress.setY(this.getY());        
        return roadAddress;
    }
    
    @Override
    public String toString() {
        return "Address{" +
                "addressName='" + addressName + '\'' +
                ", region1DepthName='" + region1DepthName + '\'' +
                ", region2DepthName='" + region2DepthName + '\'' +
                ", region3DepthName='" + region3DepthName + '\'' +
                ", region3DepthHName='" + region3DepthHName + '\'' +
                ", hCode='" + hCode + '\'' +
                ", bCode='" + bCode + '\'' +
                ", mountainYn='" + mountainYn + '\'' +
                ", mainAddressNo='" + mainAddressNo + '\'' +
                ", subAddressNo='" + subAddressNo + '\'' +
                ", x='" + x + '\'' +
                ", y='" + y + '\'' +
                '}';
    }
}