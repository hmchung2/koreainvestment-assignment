package assignment.model.excel;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExcelAddress {
    private String region1;
    private String region2;
    private String region3;
    private String region4;
    private String roadName;
    
    private String errMsg;
    private Boolean excelSuccess = false;
    
    public ExcelAddress() {
    	
    }

    public ExcelAddress(String region1, String region2, String region3, String region4) {
        this.region1 = region1;
        this.region2 = region2;
        this.region3 = region3;
        this.region4 = region4;
        this.roadName = "";
    }

    public String getRegion1() {
        return region1;
    }

    public String getRegion2() {
        return region2;
    }

    public String getRegion3() {
        return region3;
    }

    public String getRegion4() {
        return region4;
    }
    
    public void setExcelSuccess(Boolean excelSuccess ) {
    	this.excelSuccess = excelSuccess;
    }
    
    public Boolean getExcelSuccess() {
    	return excelSuccess;
    }
    
    public void setErrMsg(String errMsg) {
    	this.errMsg = errMsg;
    }
    
    public String getErrMsg() {
    	return errMsg;
    }    
    
    public String getCombinedRegion34() {
    	if (region3 != null) {
    	    if (region4 != null && !region4.isEmpty()) {
    	        return region3 + " " + region4;
    	    } else {
    	        return region3;
    	    }
    	} else if (region4 != null && !region4.isEmpty()) {
    	    return region4;
    	}else {
    		return null;
    	}
    }
    
    
    public String getRoadName() {
    	return roadName;
    }
    
    public void setRoadName(String roadName) {
    	this.roadName = roadName;
    }

    @Override
    public String toString() {
        return region1 + region2 + region3 + region4 + roadName;
    }
    
    public String apiFormatString() {
    	 return Stream.of(region1, region2, region3, region4, roadName)
    	            .filter(s -> s != null && !s.isEmpty())
    	            .collect(Collectors.joining(" "));
    }
    
}
