package assignment.service;

import assignment.exception.ApiException;
import assignment.exception.ConnectionException;
import assignment.model.ServiceOutput;
import assignment.model.KakaoApi.AddressResponse;
import assignment.model.KakaoApi.Document;
import assignment.model.excel.ExcelAddress;
import assignment.module.KakaoApiModule;
import assignment.module.ParsingByRegionModule;

public class FindBestAddrService {
	
	private KakaoApiModule kakaoApiModule;
	private ParsingByRegionModule parsingByRegionModule;
	
	// 모듈 초기화 시작
	public FindBestAddrService() {
        this.kakaoApiModule = new KakaoApiModule();
        this.parsingByRegionModule = new ParsingByRegionModule();
    }
	
    // API 사용해서 주소 파싱
    public ServiceOutput getAddrByApi(String query ) {
    	ServiceOutput serviceOutput = new ServiceOutput();
        try {
            AddressResponse addressResponse = kakaoApiModule.getKakaoResponse(query);
            if (addressResponse != null && addressResponse.getMeta().getTotalCount() > 0) {
                Document bestDocument = addressResponse.getDocuments().get(0);
                if(bestDocument.getRoadAddress() != null) {                	
                	serviceOutput.copyFromRoadAddress(bestDocument.getRoadAddress());                	
                }else  {
                	serviceOutput.copyFromRoadAddress(bestDocument.getAddress().toRoadAddress());
                }
            	serviceOutput.setErrMsg("");
            	serviceOutput.setApiSuccess(true);
            } else {
            	serviceOutput.setErrMsg("No valid address found by API for the query: " + query);            	               
            }
        } catch (Exception e) {
            serviceOutput.setErrMsg("Error occurred during API call for the query: "+ query);
        }
    	return serviceOutput;
    }   
    
    public ServiceOutput getBestAddress(String query){
    	// 처음 API 시도
    	ServiceOutput serviceOutput = getAddrByApi(query);
    	if(serviceOutput.getApiSuccess()) {    		
    		// 사용자 쿼리로 API 성공시 검증단계 3 설정 
    		serviceOutput.setValidLevel("3");
    	}else {
    		// 사용자 쿼리 실패시 엑셀로 쿼리 파싱
    		ExcelAddress excelAddress = parsingByRegionModule.execute(query);
    		
    		// 엑셀 파싱 성공시 다시 파싱된 쿼리로 API 호출
    		if(excelAddress.getExcelSuccess()) {
    			serviceOutput = getAddrByApi(excelAddress.apiFormatString());
    			
    			// 파싱 쿼리로 API 성공시 검증단계 2 설정
    			if(serviceOutput.getApiSuccess()) {
    				serviceOutput.setValidLevel("2");
    				
    			// 파싱 쿼리로도 API 호출 실패시 기본 검증단계 1 설정
    			}else {
    				serviceOutput.setRegion1DepthName(excelAddress.getRegion1());
    				serviceOutput.setRegion2DepthName(excelAddress.getRegion2());
    				serviceOutput.setRegion3DepthName(excelAddress.getCombinedRegion34());
    				serviceOutput.setRoadName(excelAddress.getRoadName());
    			}
    		// API 엑셀 모두 실패시 에러 메시지 설정
    		}else {
    			serviceOutput.setErrMsg( serviceOutput.getErrMsg() + " " +excelAddress.getErrMsg());
    		}
    	}
        return serviceOutput;
    } 
}
