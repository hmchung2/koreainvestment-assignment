package assignment;

import assignment.model.ServiceOutput;
import assignment.service.FindBestAddrService;
import java.util.Scanner;
import java.util.regex.Pattern;


public class Main {
	
    public static void main(String[] args) {
    	FindBestAddrService findBestAddrService = new FindBestAddrService();
    	Scanner scanner = new Scanner(System.in);    	    	
        Pattern pattern = Pattern.compile("^[가-힣0-9 ]+$");
        Pattern nonKoreanPattern = Pattern.compile("[^가-힣]");

        while (true) {
            System.out.print("주소를 입력하세요 ('exit'을 입력하여 종료): ");
            String userInput = scanner.nextLine();
            if (userInput.equalsIgnoreCase("exit")) {
                break;
            }

            // 한글, 숫자, 공백만 포함
            if (!pattern.matcher(userInput).matches()) {
                System.out.println("주소는 한글, 숫자, 공백만 포함해야 합니다.");
                continue;
            }

            // 최소 한글 4글자 필요
            String koreanOnlyInput = nonKoreanPattern.matcher(userInput).replaceAll("");
            if (koreanOnlyInput.length() < 4) {
                System.out.println("주소는 최소 한글 4자 이상 입력해야 합니다.");
                continue;
            }

            try {
            	ServiceOutput serviceOutput = findBestAddrService.getBestAddress(userInput);
            	System.out.println("output : "  + serviceOutput.toString());
            	
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}         
        }
        scanner.close();
        System.out.println("프로그램 종료.");
    }
}