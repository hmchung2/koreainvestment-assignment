package assignment.module;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

import assignment.exception.ApiException;
import assignment.exception.ConnectionException;
import assignment.model.KakaoApi.AddressResponse;
import assignment.util.ConfigSettings;

import com.fasterxml.jackson.databind.ObjectMapper;


public class KakaoApiModule {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public KakaoApiModule() {
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
    }

    public AddressResponse getKakaoResponse(String query) throws ConnectionException, ApiException {
        try {
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);            
            String url = ConfigSettings.getApiUrl() + "?query=" + encodedQuery;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Authorization", "KakaoAK " + ConfigSettings.getRestApiKey())
                    .GET()
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String responseBody = response.body();
                return objectMapper.readValue(responseBody, AddressResponse.class);
            } else {
                throw new ApiException("Error: " + response.statusCode() + " " + response.body());
            }
        } catch (Exception e) {
            throw new ConnectionException("Connection Error", e);
        }
    }
}