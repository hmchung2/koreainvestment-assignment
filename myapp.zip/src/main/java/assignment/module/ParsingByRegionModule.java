package assignment.module;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;

import assignment.model.excel.ExcelAddress;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ParsingByRegionModule {
    private static boolean isDataLoaded = false;
    /*
     * 중요!! : 명칭이 긴 지역명 먼저 나오게금 저장
     */
    private static Set<String> allRegion1 = new TreeSet<>(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
    private static Set<String> allRegion2 = new TreeSet<>(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
    private static Set<String> allRegion3 = new TreeSet<>(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
    private static Set<String> allRegion4 = new TreeSet<>(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
    
    
    private static List<String> regionDataList = new ArrayList<>();
    
    public ParsingByRegionModule() {
    	loadDataIfNeeded();
    }

    private static synchronized void loadDataIfNeeded() {
    	if (!isDataLoaded) {
//    		System.out.println("Start Reading Excel FIle");
    		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            try (InputStream inputStream = classloader.getResourceAsStream("전국행정동리스트.xlsx")) {
                Workbook workbook = WorkbookFactory.create(inputStream);
                Sheet sheet = workbook.getSheetAt(0);
                
                for (int i = 3; i < sheet.getLastRowNum() + 1; i++) {
                    Row row = sheet.getRow(i);
                    if (row != null) {
                        Cell cell1 = row.getCell(0);
                        Cell cell2 = row.getCell(1);
                        Cell cell3 = row.getCell(2);
                        Cell cell4 = row.getCell(3);

                        String value1 = cell1.getStringCellValue();
                        String value2 = cell2.getStringCellValue();
                        String value3 = cell3.getStringCellValue();
                        String value4 = cell4.getStringCellValue();

                        allRegion1.add(value1);
                        allRegion2.add(value2);
                        allRegion3.add(value3);
                        allRegion4.add(value4);

                        /*
                         *최소 명칭 구분 단위 2글자 포함 
                         */
                        if (value1.length() > 2) {
                            allRegion1.add(value1.substring(0, 2));
                        }
                        if (value2.length() > 2) {
                            allRegion2.add(value2.substring(0, 2));
                        }
                        if (value3.length() > 2) {
                            allRegion3.add(value3.substring(0, 2));
                        }
                        if (value4.length() > 2) {
                            allRegion4.add(value4.substring(0, 2));
                        }
                        String regionData = value1 +"_" + value2 + "_" + value3 + "_" + value4;
                        regionDataList.add(regionData);
                    }
                }
                isDataLoaded = true;
//                System.out.println("Finished Reading Excel FIle");
            } catch (IOException | EncryptedDocumentException e) {
                e.printStackTrace();
            }
        }
    }
    
    public ExcelAddress execute(String query) {
    	ExcelAddress excelAddress = new ExcelAddress();
    	
    	 if(!isDataLoaded) {
    		 excelAddress.setErrMsg("Unable to Read Excel");    		 
    		 return excelAddress;
    	 }
    	
    	 String parsedQuery = query.replaceAll("[^ㄱ-힣0-9]", "");
         String parsedRegion1 = "";
         String parsedRegion2 = "";
         String parsedRegion3 = "";
         String parsedRegion4 = "";
         String restOfWords = parsedQuery;

         String[] outputs = new String[4];
         Set<String> allRegion = allRegion1;

         // 단위가 큰 지역부터 제거 시작
         // 제일 먼저 발생 하는 단어 기준으로 제거 (명칭이 긴것부터 조회)
         for (int i = 0; i < 4; i++) {
             outputs = findMatchedRegionAndRestOfWords(restOfWords, allRegion);
             switch (i) {
                 case 0:
                     parsedRegion1 = outputs[0];
                     break;
                 case 1:
                     parsedRegion2 = outputs[0];
                     break;
                 case 2:
                     parsedRegion3 = outputs[0];
                     break;
                 case 3:
                     parsedRegion4 = outputs[0];
                     break;
             }

             restOfWords = outputs[1];
             allRegion = getNextAllRegion(i + 1);
         }
         
         // 한번 더 체크 하는 이유는 존재하는 지역명을 사용해도 적합하지 않는 조합 확인... 예시: '제주도 강남 마곡동 중앙로'
         // 중간 단위 지역 명칭 없어도 순서가 일치하고 마지막 단계 지역명칭 까지 검증해서 나오면 긍정적으로 정의 
         String regex = ".*" + parsedRegion1 + ".*" + parsedRegion2 + ".*" + parsedRegion3 + ".*" + parsedRegion4 + ".*";
         for (String regionData : regionDataList) {   
         	    if (regionData.matches(regex)) {
         	    	excelAddress = new ExcelAddress(parsedRegion1, parsedRegion2, parsedRegion3, parsedRegion4);
         	    	excelAddress.setExcelSuccess(true);
         	        break;
     	     }
         }
         if(excelAddress.getExcelSuccess()) {
             String[] splitWords;
             // 로 나 길로 끝나는 단어 찾기
             String roadPart =  null;            
             // '로 길'로 시작하는 길 이름은 두번째 '로 길'에서 스플릿
             if (restOfWords.startsWith("로") || restOfWords.startsWith("길")) {
                 splitWords = restOfWords.split("(?<=(?:로|길))");                 
                 if (splitWords.length > 1) {
                	 roadPart = splitWords[0] + splitWords[1];
                 }                
             } else {
                 splitWords = restOfWords.split("(?<=로|길)", 2);
                 if (splitWords.length > 1) {
                     roadPart = splitWords[0];
                 }
             }
             if(roadPart != null) {
            	 excelAddress.setRoadName(roadPart);
             }
        }else {
        	excelAddress.setErrMsg("Unabled to Find from Excel File : " + query);
        }    	
     	return excelAddress;
    }
    
    // 지역명칭 세트에서 반복문 실행
    // 지역명칭이 파싱된 쿼리안에 포함 되어 있으면 해당 지역으로 선정. 쿼리에서 지역명 빼고 나머지 글자들 다시 리턴
    private static String[] findMatchedRegionAndRestOfWords(String parsedQuery, Set<String> allRegion) {
        for (String region : allRegion) {
            int index = parsedQuery.indexOf(region);
            if (index != -1) {
                String matchedRegion = parsedQuery.substring(index, index + region.length());
                String restOfWords = parsedQuery.substring(index + region.length());
                return new String[]{matchedRegion, restOfWords};
            }
        }
        return new String[]{"", parsedQuery};
    }

    private static Set<String> getNextAllRegion(int index) {
        switch (index) {
            case 1:
                return allRegion2;
            case 2:
                return allRegion3;
            case 3:
                return allRegion4;
            default:
                return null;
        }
    }
     

}